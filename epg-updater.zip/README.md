# EPG Updater

Auto-updates EPG XMLTV using WebGrab+Plus and GitHub Actions.
