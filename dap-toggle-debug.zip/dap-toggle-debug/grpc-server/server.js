const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

const packageDef = protoLoader.loadSync('debug.proto');
const grpcObj = grpc.loadPackageDefinition(packageDef);
const debugPkg = grpcObj.DebugService;

const server = new grpc.Server();

server.addService(debugPkg.service, {
  Launch: (call, callback) => {
    console.log('Launch called with:', call.request.program);
    callback(null, { message: `Launched ${call.request.program}` });
  },
  Evaluate: (call, callback) => {
    console.log('Evaluating:', call.request.expression);
    callback(null, { result: `dummy_value_for_${call.request.expression}` });
  }
});

server.bindAsync('127.0.0.1:50051', grpc.ServerCredentials.createInsecure(), () => {
  server.start();
  console.log('gRPC server running at http://127.0.0.1:50051');
});
