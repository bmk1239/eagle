import * as vscode from 'vscode';

let isRunning = false;

export function activate(context: vscode.ExtensionContext) {
  const toggleCommand = vscode.commands.registerCommand('extension.toggleDebug', async () => {
    if (isRunning) {
      await vscode.commands.executeCommand('workbench.action.debug.stop');
      vscode.window.showInformationMessage('Debug session stopped');
      isRunning = false;
    } else {
      const success = await vscode.debug.startDebugging(
        vscode.workspace.workspaceFolders?.[0],
        {
          type: 'mydbg',
          name: 'My Debugger Session',
          request: 'launch',
          program: '${file}'
        }
      );

      if (success) {
        vscode.window.showInformationMessage('Debug session started');
        isRunning = true;
      } else {
        vscode.window.showErrorMessage('Failed to start debug session');
      }
    }
  });

  context.subscriptions.push(toggleCommand);
}

export function deactivate() {}
