# PowerShell script to clone GrabPlus and copy ini files

# Define variables
$grabplusRepo = 'https://github.com/GrabPlus/GrabPlus.git'
$grabplusDir = "$PWD\GrabPlus"

# Clone the repo if not exists
if (-Not (Test-Path $grabplusDir)) {
    git clone $grabplusRepo $grabplusDir
} else {
    Write-Host 'GrabPlus directory already exists.'
}

# Copy ini files to GrabPlus ini folder
$iniSourceDir = "$PWD\..\ini_sources"
$iniTargetDir = Join-Path $grabplusDir 'ini'

if (-Not (Test-Path $iniTargetDir)) {
    Write-Host "GrabPlus ini folder not found at $iniTargetDir"
    exit 1
}

Get-ChildItem -Path $iniSourceDir -Filter *.ini | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $iniTargetDir -Force
    Write-Host "Copied $($_.Name) to GrabPlus ini folder"
}
