# EPG GrabPlus Solution for Israeli Channels

## Overview
This package helps you grab Israeli EPG using GrabPlus with ini files from Israeli channel sources.

## Folder structure
- ini_sources/  (contains Israeli channel ini files)
- scripts/     (PowerShell scripts to set up GrabPlus and copy ini files)
- README.md    (this file)

## Usage

### 1. Clone GrabPlus repo (or download the latest release)
Run the `scripts/setup_grabplus.ps1` PowerShell script to clone and prepare the ini files for GrabPlus.

```powershell
cd scripts
.\setup_grabplus.ps1
```

### 2. Place your ini files into the GrabPlus ini folder  
Copy the files from `ini_sources` to the GrabPlus ini directory as shown in the script.

### 3. Run GrabPlus and generate the XMLTV EPG file  
Use GrabPlus GUI or CLI as you prefer.

### 4. Automate updates (optional)  
You can create a scheduled task or GitHub workflow to run the script daily.

---

## Israeli ini sources included (samples):
- hot.ini
- yes.ini
- kan.ini
- partner.ini

---

## Notes:
- Update ini files as needed for new channels or changes.
- The script clones from the official GrabPlus GitHub repo.
